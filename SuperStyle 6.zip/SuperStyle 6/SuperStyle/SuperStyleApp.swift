//
//  SuperStyleApp.swift
//  SuperStyle
//
//  Created by berken on 7.05.2025.
//

import SwiftUI

//@main
struct SuperStyleApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
