import Foundation
import Supabase

@MainActor
class SupabaseManager {
    static let shared = SupabaseManager()

    let client: SupabaseClient
    let storageBucket = "superstyle"

    private init() {
        self.client = SupabaseClient(
            supabaseURL: URL(string: "https://wvauzvkxelygafagujbo.supabase.co")!,
            supabaseKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Ind2YXV6dmt4ZWx5Z2FmYWd1amJvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDQ4MDMzODMsImV4cCI6MjA2MDM3OTM4M30.FHIsFxsEVP5rSVeVz6sSedAhOGhykJ6zgGsmbe-sUsc"
        )
    }
    
    // Storage'dan tüm görselleri çeken fonksiyon
    func fetchImages() async throws -> [FeedItems] {
        // Storage'dan dosya listesini çek
        let storage = client.storage
        let bucket = storage.from(storageBucket)
        
        // Asenkron liste çağrısı
        let files = try await bucket.list()
        
        var feedItems = [FeedItems]()
        
        // Her dosya için bir FeedItems oluştur
        for file in files {
            if file.name.hasSuffix(".jpg") || file.name.hasSuffix(".png") || file.name.hasSuffix(".jpeg") {
                // Görselin public URL'ini al
                let publicURL = try await bucket.createSignedURL(path: file.name, expiresIn: 3600)
                
                let item = FeedItems(
                    imageName: file.name,
                    imageURL: publicURL,
                    username: "User", // Gerçek kullanıcı bilgileri sonra eklenebilir
                    timestamp: "\(Int.random(in: 1...59))m" // Örnek zaman damgası
                )
                feedItems.append(item)
            }
        }
        
        return feedItems
    }
}
