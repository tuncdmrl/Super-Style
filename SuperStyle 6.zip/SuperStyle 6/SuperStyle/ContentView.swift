//
//  ContentView.swift
//  SuperStyle
//
//  Created by berken on 7.05.2025.
//

import SwiftUI
import CoreData

struct ContentView: View {
    @StateObject var viewModel = ContentViewModel()
    @AppStorage("isLoggedIn") var isLoggedIn: Bool = false

    var body: some View {
        Group {
            if isLoggedIn {
                WWWTabView()
            } else {
                LoginView()
                    .environmentObject(viewModel)
                    .onChange(of: viewModel.loginSuccess) { newValue in
                        if newValue {
                            isLoggedIn = true
                        }
                    }
            }
        }
    }
}

#Preview {
    ContentView()
}
