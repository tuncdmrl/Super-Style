//
//  ExploreView.swift
//  WWW
//
//  Created by tunc on 3.03.2025.
//

import SwiftUI

struct ExploreView: View {
    @State private var searchText = ""
    @ObservedObject var manager: FeedManager
    
    var filteredUsers: [FeedItems] {
        if searchText.isEmpty {
            return manager.feedItems
        } else {
            return manager.feedItems.filter { user in
                user.username.localizedCaseInsensitiveContains(searchText)
            }
        }
    }
    
    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack {
                    ForEach(filteredUsers) { user in
                        UserCell(user: user, manager: manager)
                        Divider()
                    }
                }
            }
            .navigationTitle("Search")
            .searchable(text: $searchText, prompt: "Search users")
        }
    }
}

#Preview {
    ExploreView(manager: FeedManager())
}
