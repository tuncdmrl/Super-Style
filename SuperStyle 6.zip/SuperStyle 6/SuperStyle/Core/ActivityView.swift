//
//  ActivityView.swift
//  WWW
//
//  Created by tunc on 3.03.2025.
//

import SwiftUI

struct ActivityView: View {
    @ObservedObject var manager: FeedManager
    var body: some View {
        VStack(alignment: .leading) {
            Text("Beğendiğin Gönderiler")
                .font(.headline)
                .padding(.bottom, 8)
            if manager.likedItems.isEmpty {
                Text("Henüz beğendiğin bir gönderi yok.")
                    .foregroundColor(.gray)
            } else {
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 16) {
                        ForEach(manager.likedItems) { item in
                            HStack(spacing: 12) {
                                CircularProfilePageView(imageName: item.profileImageName)
                                VStack(alignment: .leading) {
                                    Text(item.username)
                                        .font(.subheadline)
                                        .fontWeight(.semibold)
                                    Text(item.timestamp)
                                        .font(.caption)
                                        .foregroundColor(.gray)
                                }
                                Spacer()
                                Image(item.imageName)
                                    .resizable()
                                    .frame(width: 60, height: 60)
                                    .clipShape(RoundedRectangle(cornerRadius: 8))
                            }
                        }
                    }
                }
            }
        }
        .padding()
    }
}

#Preview {
    ActivityView(manager: FeedManager())
}
