import SwiftUI
struct ProfileView: View {
    @ObservedObject var manager: FeedManager
    @StateObject var viewModel = RegistrationViewModel()
    @State private var selectedTab = "Follow"
    @Namespace private var animation
    @State private var showSettings = false

    var body: some View {
        NavigationStack {
            VStack {
                HStack {
                    Spacer()
                    Text(viewModel.username)
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                    Spacer()
                    Button(action: {
                        showSettings.toggle()
                    }) {
                        Image(systemName: "gearshape")
                            .font(.title2)
                            .foregroundColor(.black)
                    }
                }
                .padding()

                Divider()

                VStack(spacing: 5) {
                    HStack {
                        Button(action: {
                            withAnimation(.spring()) {
                                selectedTab = "Follow"
                            }
                        }) {
                            VStack {
                                Text("Follow")
                                    .font(.title2)
                                    .fontWeight(selectedTab == "Follow" ? .bold : .regular)
                                    .foregroundColor(selectedTab == "Follow" ? .black : .gray)

                                if selectedTab == "Follow" {
                                    Rectangle()
                                        .frame(height: 2)
                                        .foregroundColor(.black)
                                        .matchedGeometryEffect(id: "tabIndicator", in: animation)
                                } else {
                                    Color.clear.frame(height: 2)
                                }
                            }
                        }
                        .frame(maxWidth: .infinity)

                        Button(action: {
                            withAnimation(.spring()) {
                                selectedTab = "Liked"
                            }
                        }) {
                            VStack {
                                Text("Liked")
                                    .font(.title2)
                                    .fontWeight(selectedTab == "Liked" ? .bold : .regular)
                                    .foregroundColor(selectedTab == "Liked" ? .black : .gray)

                                if selectedTab == "Liked" {
                                    Rectangle()
                                        .frame(height: 2)
                                        .foregroundColor(.black)
                                        .matchedGeometryEffect(id: "tabIndicator", in: animation)
                                } else {
                                    Color.clear.frame(height: 2)
                                }
                            }
                        }
                        .frame(maxWidth: .infinity)
                    }
                }
                .padding(.horizontal)

                TabView(selection: $selectedTab) {
                    // Follow sekmesi
                    ScrollView {
                        if manager.followedUsers.isEmpty {
                            Text("Henüz kimseyi takip etmiyorsun")
                                .foregroundColor(.gray)
                        } else {
                            VStack(spacing: 16) {
                                // Takip edilen kullanıcıların grid görünümü
                                LazyVGrid(columns: [
                                    GridItem(.flexible()),
                                    GridItem(.flexible()),
                                    GridItem(.flexible())
                                ], spacing: 16) {
                                    ForEach(manager.followedUsers) { user in
                                        NavigationLink(destination: CelebrityProfileView(user: user)) {
                                            VStack {
                                                CircularProfilePageView(imageName: user.profileImageName)
                                                    .frame(width: 80, height: 80)
                                                Text(user.username)
                                                    .font(.footnote)
                                                    .fontWeight(.semibold)
                                                    .foregroundColor(.black)
                                            }
                                        }
                                    }
                                }
                                .padding(.horizontal)
                                
                                Divider()
                                
                                // Takip edilen kullanıcıların liste görünümü
                                LazyVStack(spacing: 0) {
                                    ForEach(manager.followedUsers) { user in
                                        UserCell(user: user, manager: manager)
                                        Divider()
                                    }
                                }
                            }
                        }
                    }
                    .tag("Follow")

                    // Liked sekmesi
                    ScrollView {
                        if manager.likedItems.isEmpty {
                            Text("Not Liked Yet")
                                .foregroundColor(.gray)
                        } else {
                            LazyVStack(spacing: 0) {
                                ForEach(manager.likedItems.indices, id: \.self) { idx in
                                    WWWCell(item: .constant(manager.likedItems[idx]), likeAction: {
                                        manager.toggleLike(for: manager.likedItems[idx])
                                    })
                                }
                            }
                        }
                    }
                    .tag("Liked")
                }
                .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
            }
            .sheet(isPresented: $showSettings) {
                SettingsSheetView()
            }
        }
    }
}

// ⚙️ Ayarlar Sayfası + Logout
struct SettingsSheetView: View {
    @AppStorage("isLoggedIn") var isLoggedIn: Bool = true

    var body: some View {
        NavigationStack {
            List {
                Label("Notifications", systemImage: "bell")
                Label("Privacy", systemImage: "lock")
                Label("Account", systemImage: "person")
                Label("Help", systemImage: "questionmark.circle")
                Label("About", systemImage: "info.circle")

                Section {
                    Button {
                        isLoggedIn = false // Oturumu kapat
                    } label: {
                        Label("Log Out", systemImage: "arrow.backward.circle")
                            .foregroundColor(.red)
                    }
                }
            }
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    ProfileView(manager: FeedManager())
}
