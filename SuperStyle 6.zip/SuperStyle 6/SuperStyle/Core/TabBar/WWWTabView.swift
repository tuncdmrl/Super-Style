import SwiftUI

struct WWWTabView: View {
    @State private var selectedTab = 0
    @StateObject private var manager = FeedManager()
    var body: some View {
        TabView(selection:$selectedTab) {
            FeedView(manager: manager)
                .tabItem {
                    Image(systemName: selectedTab == 0 ? "house.fill" : "house")
                        .environment(\.symbolVariants, selectedTab == 0 ? .fill : .none)
                }
                .onAppear{selectedTab = 0 }
                .tag(0)
            ExploreView(manager: manager)
                .tabItem {
                    Image(systemName: "magnifyingglass")
                }
                .onAppear{selectedTab = 1 }
                .tag(1)
            ActivityView(manager: manager)
                .tabItem {
                    Image(systemName: selectedTab == 2 ? "heart.fill" : "heart")
                        .environment(\.symbolVariants, selectedTab == 2 ? .fill : .none)
                }
                .onAppear{selectedTab = 2 }
                .tag(2)
            ProfileView(manager: manager)
                .tabItem {
                    Image(systemName: selectedTab == 3 ? "person.fill" : "person")
                        .environment(\.symbolVariants, selectedTab == 3 ? .fill : .none)
                }
                .onAppear{selectedTab = 3 }
                .tag(3)
        }
        .tint(.black)
    }
}
#Preview {
    WWWTabView()
}
