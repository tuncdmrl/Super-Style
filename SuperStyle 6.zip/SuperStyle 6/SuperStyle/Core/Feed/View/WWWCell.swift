import SwiftUI

struct WWWCell: View {
    @Binding var item: FeedItems
    var likeAction: () -> Void
    @Environment(\.openURL) var openURL

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .top, spacing: 12) {
                // Profil fotoğrafı tıklanabilir
                NavigationLink(destination: CelebrityProfileView(user: item)) {
                    CircularProfilePageView(imageName: item.profileImageName)
                }
                VStack(alignment: .leading, spacing: 4) {
                    HStack {
                        // Kullanıcı adı tıklanabilir
                        NavigationLink(destination: CelebrityProfileView(user: item)) {
                            Text(item.username)
                                .font(.footnote)
                                .fontWeight(.semibold)
                        }
                        Spacer()
                        Text(item.timestamp)
                            .font(.caption)
                            .foregroundColor(Color(.systemGray3))
                        Button {
                        } label: {
                            Image(systemName: "ellipsis")
                                .foregroundColor(Color(.darkGray))
                        }
                    }
                    
                    // Görsele tıklanınca link açılacak şekilde düzenlendi
                    if let imageURL = item.imageURL {
                        AsyncImage(url: imageURL) { phase in
                            switch phase {
                            case .empty:
                                ProgressView()
                                    .frame(maxWidth: .infinity, minHeight: 200)
                            case .success(let image):
                                image
                                    .resizable()
                                    .scaledToFit()
                                    .frame(maxWidth: .infinity)
                                    .cornerRadius(10)
                                    .onTapGesture {
                                        if let url = URL(string: item.linkURL), !item.linkURL.isEmpty {
                                            openURL(url)
                                        }
                                    }
                            case .failure:
                                Image(systemName: "photo")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(maxWidth: .infinity, minHeight: 200)
                                    .foregroundColor(.gray)
                            @unknown default:
                                EmptyView()
                            }
                        }
                    } else {
                        Image(item.imageName)
                            .resizable()
                            .scaledToFit()
                            .frame(maxWidth: .infinity)
                            .cornerRadius(10)
                            .onTapGesture {
                                if let url = URL(string: item.linkURL), !item.linkURL.isEmpty {
                                    openURL(url)
                                }
                            }
                    }
                    
                    HStack(spacing: 8) {
                        ForEach(Array(item.additionalImageNames.enumerated()), id: \.offset) { (index, imageName) in
                            let link = (index < item.additionalLinks.count) ? item.additionalLinks[index] : ""
                            Image(imageName)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 60, height: 60)
                                .clipShape(RoundedRectangle(cornerRadius: 8))
                                .onTapGesture {
                                    if !link.isEmpty, let url = URL(string: link) {
                                        openURL(url)
                                    }
                                }
                        }
                    }
                    
                    HStack {
                        Button {
                            likeAction()
                        } label: {
                            Image(systemName: item.isLiked ? "heart.fill" : "heart")
                                .foregroundColor(item.isLiked ? .red : .black)
                        }
                        
                        Spacer()
                    }
                    .padding(.vertical, 8)
                }
            }
            .padding()
            
            Divider()
        }
    }
}
