import SwiftUI

struct FeedView: View {
    @ObservedObject var manager: FeedManager
    @State private var isLoading = false
    @State private var errorMessage: String?
    
    var body: some View {
        NavigationStack {
            ZStack {
                if isLoading {
                    ProgressView()
                } else if let error = errorMessage {
                    VStack {
                        Text("Yükleme hatası")
                            .font(.headline)
                        Text(error)
                            .font(.subheadline)
                            .foregroundColor(.gray)
                        Button("Tekrar Dene") {
                            Task {
                                await fetchImages()
                            }
                        }
                        .padding(.top)
                    }
                } else if manager.feedItems.isEmpty {
                    Text("Gösterilecek görseller bulunamadı")
                        .foregroundColor(.gray)
                } else {
                    ScrollView {
                        LazyVStack(spacing: 0) {
                            ForEach(manager.feedItems.indices, id: \.self) { idx in
                                WWWCell(item: $manager.feedItems[idx], likeAction: {
                                    manager.toggleLike(for: manager.feedItems[idx])
                                })
                            }
                        }
                    }
                }
            }
            .refreshable {
                await fetchImages()
            }
            .navigationTitle("Who is Wearing What")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        Task {
                            await fetchImages()
                        }
                    } label: {
                        Image(systemName: "arrow.counterclockwise")
                            .foregroundColor(.black)
                    }
                }
            }
            .task {
                if manager.feedItems.isEmpty {
                    await fetchImages()
                }
            }
        }
    }
    
    func fetchImages() async {
        // Supabase kullanımını geçici olarak devre dışı bırakıyoruz
        // feedItems = try await SupabaseManager.shared.fetchImages()
    }
}

#Preview {
    FeedView(manager: FeedManager())
}
