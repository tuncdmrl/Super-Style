//
//  ProfileWWWFilter.swift
//  WWW
//
//  Created by tunc on 12.03.2025.
//

import Foundation
// enum arastir
enum ProfileWWWFilter: Int, CaseIterable {
    
    case www
    case replies 
    var title: String {
        switch self {
        case.www: return "www"
        case.replies:return "Replies"
        }
    }
    
    
}
