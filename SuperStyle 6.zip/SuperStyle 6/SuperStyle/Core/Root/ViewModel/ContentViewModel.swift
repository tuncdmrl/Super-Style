import SwiftUI
import Supabase

class ContentViewModel: ObservableObject {
    @Published var loginSuccess = false
    @Published var errorMessage = ""
    @Published var email = ""
    @Published var password = ""
    
    @MainActor
    func login(email: String, password: String) async {
        do {
            // Supabase giriş işlemi
            let response = try await SupabaseManager.shared.client.auth.signIn(
                email: email,
                password: password
            )
            
            loginSuccess = true
            errorMessage = ""
            print("Signed in user: \(response.user.email ?? "no email")")
            
        } catch {
            loginSuccess = false
            errorMessage = parseAuthError(error)
            print("Supabase login error: \(error.localizedDescription)")
        }
    }
    
    func logout() async {
        do {
            try await SupabaseManager.shared.client.auth.signOut()
            
            await MainActor.run {
                loginSuccess = false
                email = ""
                password = ""
                errorMessage = ""
            }
            
            print("Successfully signed out from Supabase")
        } catch {
            await MainActor.run {
                errorMessage = "Error signing out: \(error.localizedDescription)"
            }
            print("Error signing out from Supabase: \(error.localizedDescription)")
        }
    }
    
    // Hata mesajlarını kullanıcı dostu hale getirme
    private func parseAuthError(_ error: Error) -> String {
        let message = error.localizedDescription.lowercased()
        
        if message.contains("email") && message.contains("password") {
            return "Geçersiz email veya şifre"
        } else if message.contains("network") {
            return "Ağ bağlantı sorunu. Lütfen internet bağlantınızı kontrol edin"
        } else if message.contains("user not found") {
            return "Bu email ile kayıtlı kullanıcı bulunamadı"
        } else {
            return "Giriş yapılırken bir hata oluştu"
        }
    }
}
