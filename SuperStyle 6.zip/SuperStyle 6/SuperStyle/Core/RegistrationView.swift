import SwiftUI

struct RegistrationView: View {
    @StateObject var viewModel = RegistrationViewModel()
    @Environment(\.dismiss) var dismiss
    @State private var showingAlert = false
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    // Logo ve Başlık
                    VStack {
                        Image("Dark-Clean")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 120, height: 120)
                        
                        Text("Super Style")
                            .font(.title2)
                            .fontWeight(.semibold)
                    }
                    .padding(.top, 20)
                    
                    // Form Alanları
                    VStack(spacing: 16) {
                        TextField("email", text: $viewModel.email)
                            .modifier(WWWTextFieldModifier())
                            .keyboardType(.emailAddress)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                        
                        SecureField("password", text: $viewModel.password)
                            .modifier(WWWTextFieldModifier())
                        
                        TextField("name", text: $viewModel.fullname)
                            .modifier(WWWTextFieldModifier())
                            .textInputAutocapitalization(.words)
                        
                        TextField("username", text: $viewModel.username)
                            .modifier(WWWTextFieldModifier())
                            .textInputAutocapitalization(.none)
                            .autocorrectionDisabled()
                    }
                    .padding(.horizontal)
                    
                    // Kayıt Butonu
                    Button(action: {
                        Task {
                            await viewModel.createUser()
                            if viewModel.isUserCreated {
                                dismiss()
                            } else if !viewModel.errorMessage.isEmpty {
                                showingAlert = true
                            }
                        }
                    }) {
                        Text("Kayıt Ol")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .frame(height: 50)
                            .background(Color.black)
                            .cornerRadius(10)
                            .padding(.horizontal)
                    }
                    .disabled(viewModel.isLoading)
                    .padding(.top, 10)
                    
                    // Giriş Sayfasına Yönlendirme
                    Button(action: { dismiss() }) {
                        HStack(spacing: 3) {
                            Text("Zaten hesabınız var mı?")
                            Text("Giriş Yapın")
                                .fontWeight(.semibold)
                        }
                        .font(.footnote)
                        .foregroundColor(.black)
                    }
                    .padding(.vertical)
                }
                .padding()
            }
            .alert("Hata", isPresented: $showingAlert) {
                Button("Tamam", role: .cancel) { }
            } message: {
                Text(viewModel.errorMessage)
            }
            .overlay {
                if viewModel.isLoading {
                    ProgressView()
                        .scaleEffect(1.5)
                }
            }
        }
    }
}

#Preview {
    RegistrationView()
}
