//
//  WWWTextFieldModifier.swift
//  WWW
//
//  Created by tunc on 18.02.2025.
//
//BURAYI BERKENE SOR VIDEODA ANLATMIYO DIREKT Hazir bunlari kopyaladi ???? bunlari yazdiktan sonra loginviewe donup fontlari siliyo niye?
import SwiftUI

struct WWWTextFieldModifier: ViewModifier{
    
    
    func body(content: Content) -> some View {
        content
            .font(.subheadline)
            .padding(12)
            .background(Color(.systemGray6))
            .cornerRadius(10)
            .padding(.horizontal,24)
    }
}
