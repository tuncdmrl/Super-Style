import SwiftUI

struct WWWImageModifier: ViewModifier {
   func body(content: Content) -> some View {
        GeometryReader { geometry in
            content
                .aspectRatio(contentMode: .fit)  // Orijinal boyutları korur
                .frame(width: geometry.size.width * 0.8, height: geometry.size.height * 0.8) // Ekranın genişliği ve yüksekliğine göre uyum sağlar
                .clipShape(RoundedRectangle(cornerRadius: 15))
              .shadow(radius: 5)
                .padding()
        }
    }
}

extension Image {
   func wwwStyle() -> some View {
       self.modifier(WWWImageModifier())
  }
}








