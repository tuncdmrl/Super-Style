import SwiftUI

struct LoginView: View {
    @EnvironmentObject var viewModel: ContentViewModel 

    var body: some View {
        NavigationStack {
            VStack {
                Spacer()
                Image("iconnew")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 120 , height: 120)
                    .padding()
                VStack {
                    TextField ("Enter your email", text: $viewModel.email)
//                        .autocapitalization(.none)
                        .modifier(WWWTextFieldModifier())

                    SecureField("Enter your password", text: $viewModel.password)
                        .modifier(WWWTextFieldModifier())
                }
                NavigationLink {
                    Text("Forgot password") //todo
                } label: {
                    Text("Forgot Password?")
                        .font(.footnote)
                        .fontWeight(.semibold)
                        .padding(.vertical)
                        .padding(.trailing,28)
                        .foregroundColor(.black)
                        .frame(maxWidth: .infinity , alignment: .trailing)
                }

                Button {
                    Task { try await viewModel.login(email: viewModel.email, password: viewModel.password) }
                }
                label : {
                    Text("Login")
                        .font(.subheadline)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .frame(width: 352, height: 44)
                        .background(.black)
                        .cornerRadius(8)
                }
                .disabled(viewModel.email.isEmpty || viewModel.password.isEmpty)

                if !viewModel.errorMessage.isEmpty {
                    Text(viewModel.errorMessage)
                        .foregroundColor(.red)
                        .padding(.top)
                }

                Spacer()
                Divider ()
                NavigationLink{
                    RegistrationView()
                        .navigationBarBackButtonHidden(true)
                } label: {
                    HStack(spacing:3) {
                        Text ("Don't have an account")
                        Text ("Sign Up")
                            .fontWeight(.semibold)
                    }
                    .foregroundColor(.black)
                    .font(.footnote)
                }
                .padding(.vertical, 16)
            }
        }
    }
}
#Preview {
    LoginView()
        .environmentObject(ContentViewModel())
}
