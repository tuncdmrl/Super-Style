//
//  RegistrationViewModel.swift
//  WWW
//
//  Created by tunc on 16.04.2025.
//

import Foundation
import Supabase

class RegistrationViewModel: ObservableObject {
    @Published var email = ""
    @Published var password = ""
    @Published var fullname = ""
    @Published var username = ""
    @Published var isLoading = false
    @Published var isUserCreated = false
    @Published var errorMessage = ""
    
    @MainActor
    func createUser() async {
        isLoading = true
        errorMessage = ""
        
        // Basit validasyon
        guard !email.isEmpty, !password.isEmpty, !fullname.isEmpty, !username.isEmpty else {
            errorMessage = "Lütfen tüm alanları doldurun"
            isLoading = false
            return
        }
        
        guard password.count >= 6 else {
            errorMessage = "Şifre en az 6 karakter olmalıdır"
            isLoading = false
            return
        }
        
        do {
            let response = try await SupabaseManager.shared.client.auth.signUp(
                email: email,
                password: password,
                data: [
                    "full_name": AnyJSON(stringLiteral: fullname),
                    "username": AnyJSON(stringLiteral: username)
                ]
            )
            
            isUserCreated = true
        } catch {
            errorMessage = error.localizedDescription
            print("Registration error: \(error)")
        }
        
        isLoading = false
    }
}
