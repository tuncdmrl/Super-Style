//
//  UserCell.swift
//  WWW
//
//  Created by tunc on 12.03.2025.
//

import SwiftUI

struct UserCell: View {
    let user: FeedItems
    @ObservedObject var manager: FeedManager
    
    var body: some View {
        HStack {
            NavigationLink(destination: CelebrityProfileView(user: user)) {
                HStack {
                    CircularProfilePageView(imageName: user.profileImageName)
                    VStack(alignment: .leading) {
                        Text(user.username)
                            .fontWeight(.semibold)
                        Text("@" + user.username.lowercased())
                            .foregroundColor(.gray)
                    }
                    .font(.footnote)
                }
            }
            Spacer()
            
            Button {
                manager.toggleFollow(for: user)
            } label: {
                Text(user.isFollowing ? "Following" : "Follow")
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    .foregroundColor(user.isFollowing ? .black : .white)
                    .frame(width: 100, height: 32)
                    .background(user.isFollowing ? Color.clear : Color.black)
                    .overlay {
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.gray, lineWidth: 1.0)
                    }
            }
        }
        .padding(.horizontal)
    }
}

#Preview {
    UserCell(user: FeedItems.mockData[0], manager: FeedManager())
}
