//
//  CircularProfilePageView.swift
//  WWW
//
//  Created by tunc on 12.03.2025.
//

import SwiftUI

struct CircularProfilePageView: View {
    let imageName: String
    var body: some View {
        Image(imageName)
            .resizable()
            .scaledToFill()
            .frame(width: 40, height: 40)
            .clipShape(Circle())
    }
}

#Preview {
    CircularProfilePageView(imageName: "profile_default")
}
