//
//  CelebrityProfileView.swift
//  WWW
//
//  Created by tunc on 5.03.2025.
//

import SwiftUI

struct CelebrityProfileView: View {
    let user: FeedItems
    var body: some View {
        VStack(alignment: .leading) {
            HStack(spacing: 16) {
                CircularProfilePageView(imageName: user.profileImageName)
                    .frame(width: 60, height: 60)
                VStack(alignment: .leading) {
                    Text(user.username)
                        .font(.title2)
                        .fontWeight(.bold)
                    Text("@" + user.username.lowercased())
                        .font(.subheadline)
                        .foregroundColor(.gray)
                }
            }
            .padding()
            Divider()
            // Kullanıcının gönderileri (şimdilik 1 ana gönderi ve 3 küçük görsel)
            WWWCell(item: .constant(user), likeAction: {})
        }
        .navigationTitle(user.username)
    }
}

#Preview {
    CelebrityProfileView(user: FeedItems.mockData[0])
}
