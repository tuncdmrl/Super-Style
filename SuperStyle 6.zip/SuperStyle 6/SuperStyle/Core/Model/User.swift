//
//  User.swift
//  WWW
//
//  Created by tunc on 9.04.2025.
//

import Foundation

struct User : Identifiable , Codable {
    let id: String
    let fullname: String
    let email : String
    let username : String
    var profileImageUrl : String?

}
