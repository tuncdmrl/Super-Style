import SwiftUI

struct FeedItems: Identifiable, Codable {
    let id: UUID
    var isLiked: Bool
    var imageName: String // Supabase storage'da görselin yolu
    var imageURL: URL? // Görselin indirilen URL'i (isteğe bağlı)
    var username: String
    var timestamp: String
    var linkURL: String // Yeni eklenen bağlantı alanı
    var profileImageName: String // Profil fotoğrafı için görsel adı
    var additionalImageNames: [String] // Ekstra görseller için dizi
    var additionalLinks: [String] // Ekstra görsellerin linkleri
    var isFollowing: Bool // Takip durumu için yeni alan

    init(
        id: UUID = UUID(),
        isLiked: Bool = false,
        imageName: String = "motive",
        imageURL: URL? = nil,
        username: String = "Motive",
        timestamp: String = "10m",
        linkURL: String = "",
        profileImageName: String = "profile_default",
        additionalImageNames: [String] = [],
        additionalLinks: [String] = [],
        isFollowing: Bool = false
    ) {
        self.id = id
        self.isLiked = isLiked
        self.imageName = imageName
        self.imageURL = imageURL
        self.username = username
        self.timestamp = timestamp
        self.linkURL = linkURL
        self.profileImageName = profileImageName
        self.additionalImageNames = additionalImageNames
        self.additionalLinks = additionalLinks
        self.isFollowing = isFollowing
    }
}

class FeedManager: ObservableObject {
    @Published var feedItems: [FeedItems] = FeedItems.mockData
    @Published var likedItems: [FeedItems] = []
    @Published var followedUsers: [FeedItems] = []
    
    func toggleLike(for item: FeedItems) {
        if let index = feedItems.firstIndex(where: { $0.id == item.id }) {
            feedItems[index].isLiked.toggle()
            if feedItems[index].isLiked {
                if !likedItems.contains(where: { $0.id == item.id }) {
                    likedItems.append(feedItems[index])
                }
            } else {
                likedItems.removeAll { $0.id == item.id }
            }
        }
    }
    
    func toggleFollow(for item: FeedItems) {
        if let index = feedItems.firstIndex(where: { $0.id == item.id }) {
            feedItems[index].isFollowing.toggle()
            if feedItems[index].isFollowing {
                if !followedUsers.contains(where: { $0.id == item.id }) {
                    followedUsers.append(feedItems[index])
                }
            } else {
                followedUsers.removeAll { $0.id == item.id }
            }
        }
    }
}
