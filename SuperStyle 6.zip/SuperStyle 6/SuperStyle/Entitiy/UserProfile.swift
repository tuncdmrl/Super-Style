//
//  UserProfile.swift
//  WWW
//
//  Created by tunc on 16.04.2025.
//

import Foundation

final class UserProfile: Encodable {
    let id: String
    let email: String
    let username: String
    let fullname: String
    let created_at: String
    
    init(id: String, email: String, username: String, fullname: String, created_at: String) {
        self.id = id
        self.email = email
        self.username = username
        self.fullname = fullname
        self.created_at = created_at
    }
}
