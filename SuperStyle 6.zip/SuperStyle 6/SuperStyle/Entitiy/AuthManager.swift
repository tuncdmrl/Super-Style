//
//  AuthManager.swift
//  WWW
//
//  Created by tunc on 16.04.2025.
//

import Foundation
import Supabase
import SwiftUI

class AuthManager: ObservableObject {
    static let shared = AuthManager()
    private init() {}
    
    @Published var isLoggedIn = false
    @Published var currentUserEmail: String?
    
    func login(email: String, password: String) async -> Bool {
        do {
            let response = try await SupabaseManager.shared.client.auth.signIn(
                email: email,
                password: password
            )
            await MainActor.run {
                isLoggedIn = true
                currentUserEmail = response.user.email
            }
            return true
        } catch {
            print("Login error: \(error)")
            return false
        }
    }
    
    func logout() async {
        do {
            try await SupabaseManager.shared.client.auth.signOut()
            await MainActor.run {
                isLoggedIn = false
                currentUserEmail = nil
            }
        } catch {
            print("Logout error: \(error)")
        }
    }
}
